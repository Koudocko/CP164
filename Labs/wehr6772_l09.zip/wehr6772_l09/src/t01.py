"""
-------------------------------------------------------
Lab 7 Testing
-------------------------------------------------------
Author:  Tyler Wehrle
ID:      169056772
Email:   wehr6772@mylaurier.ca
__updated__ = "2024-01-01"
-------------------------------------------------------
"""

from Hash_Set_array import *

x = Hash_Set(5)
x.insert(55)
x.insert(11)
x.insert(22)
x.insert(33)
x.insert(43)
x.insert(53)
x.insert(63)
x.insert(73)
x.insert(83)
x.insert(93)
x.insert(103)
x.insert(113)
x.insert(123)
x.insert(133)
x.insert(143)
x.insert(153)
x.insert(163)
x.insert(173)
x.insert(183)
x.insert(193)
x.insert(203)
x.insert(213)
x.insert(223)
x.insert(233)
# x.insert(243)
# x.insert(253)
# x.insert(263)
# x.insert(273)
# x.insert(283)
# x.insert(293)
# x.insert(44)
x.debug()
