"""
-------------------------------------------------------
Lab 4 Testing
-------------------------------------------------------
Author:  Tyler Wehrle
ID:      169056772
Email:   wehr6772@mylaurier.ca
__updated__ = "2024-01-01"
-------------------------------------------------------
"""

from utilities import stack_test

source = [1, 2, 2, 3, 3, 3, 2, 2, 1]
print(f"source: {source}")

stack_test(source)
